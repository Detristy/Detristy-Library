---
tags:
  - 构造
---
https://codeforces.com/contest/2266/problem/D

