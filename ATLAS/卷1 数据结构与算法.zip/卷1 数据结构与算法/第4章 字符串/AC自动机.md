---
tags:
  - 算法
  - 数据结构
  - 字符串
  - Trie
  - KMP
  - AC自动机
aliases:
  - Aho-Corasick
---
AC 自动机以 [[trie]] 结构为基础，结合 [[KMP]] 的失配跳转思想，用于解决**多模式串匹配**问题：给定若干模式串和一个主串，一次性求出所有模式串在主串中的出现次数（或所有出现位置）。

# 1. trie 的构建

将所有模式串插入同一棵 trie，AC 自动机就建立在这棵 trie 之上。

trie 中每个结点对应"所有模式串前缀集合"中的一个元素，我们把它视作 AC 自动机的一个**状态**；结点间的边代表**状态转移**：从状态 $u$ 沿字符 $c$ 的边走到 $v$，意味着在 $u$ 表示的前缀末尾追加 $c$，得到 $v$ 表示的前缀。

# 2. fail指针

我们引入一个 fail 指针来辅助多模式串的匹配。

## 2.1 fail指针的引入

在失配时，我们当然不希望从头开始，防止重复比较导致复杂度被过多牺牲。

类比KMP失配时， $t$ 跳到 $nxt[t-1]$ 的情况（下文中用 next 指针指代），在AC自动机进行匹配的时候，当失配时我们也需要让指针跳到某个位置继续接下来的匹配。故而我们引入失配指针（fail指针）。

fail 指针和 next 指针不同的点在于：

next指针求的是最长的相同前后缀，而 fail 指针指向的是所有模式串的前缀中匹配当前状态的最长后缀。

我们来举例说明：
我们使用字符串 he ，she 和 her 来构建下面这棵 trie，root 是根节点，

```
        root
       /    \
      h      s
     /        \
    he         sh
    /            \
   her            she
```

假如我们在 sh 处失配了，我们不希望回到 root 重新开始，而我们发现 sh 的后缀 h 恰好是 trie 中已经存在的一个路径，于是 sh 处的失配指针指向 h。

同理 she 处的失配指针指向 he。

## 2.2 fail指针的构建

### 2.2.1 构建理论

参考 KMP 中 next 指针的构造，我们为 AC 自动机构建 fail 指针。

考虑一个 trie 中的结点 $u$ ，其父节点为 $p$ ，结点 $p$ 通过字符 $x$ 的边连向 $u$ ，我们记之为 $\mathrm{trie}(p,c)=u$ 。

我们使用 BFS 递归构建 fail 指针。

显然，root 的 fail 指针指向自己。
root 的所有子节点均只有一个字符，没有真前缀，因此它们的 fail 指针也指向 root。

 接下来假设深度比 $u$ 小的所有结点都已求出：
1. 若 $\mathrm{trie}(\mathrm{fail}(p),c)$ 存在，则 $u$ 的 fail 指针指向 $\mathrm{trie}(\mathrm{fail}(p),c)$ 。
2. 若不存在，则我们继续往下找 $\mathrm{trie}(\mathrm{fail}(\mathrm{fail}(p)),c)$ 直到根节点停止。
3. 如果第二步无法找到，则让 fail 指针指向根节点。

### 2.2.2 构建的实现

#### 准备工作

构建的实现将在 [[trie]] 的模板代码中进行修改。
首先对原本的 insert 函数进行修改，原本的 cnt 数组代表的是每个字符的前缀计数，但是在AC自动机中，我们要在完成一次前缀匹配才记一次数，因此我们要把 `cnt[u]++` 放在循环外面而不是里面。

```cpp
void insert(string s) {  
    int u = 0;  
    for (char c : s) {  
        int v = get_id(c);  
        if (!nxt[u][v]) nxt[u][v] = ++idx;  
        u = nxt[u][v];  
    }  
    cnt[u]++;  //注意这里和普通的 trie 有所区别
}
```

#### 处理 fail 指针

既然是 BFS，我们引入队列。

首先先预处理，将根节点以及根节点直接连接的所有结点的 fail 指针都连向根节点。

接下来开始跑 BFS，通过对刚刚的理论描述我们能写出下述代码：

```cpp
void findFail() {  
    queue<int> q;  
    for (int i = 0; i < 62; i++) {  
        if (nxt[0][i]) {  
            fail[nxt[0][i]] = 0;  
            q.push(nxt[0][i]);  
        }  
    }  
    while (!q.empty()) {  
        int u = q.front();  
        q.pop();  
        for (int i = 0; i < 62; i++) {  
            if (nxt[u][i]) {  
                int f = fail[u];  
                while (f != 0 && !nxt[f][i]) {  
                    f = fail[f];  
                }  
                if (nxt[f][i] && nxt[f][i] != nxt[u][i]) {  
                    fail[nxt[u][i]] = nxt[f][i];  
                } else {  
                    fail[nxt[u][i]] = 0;  
                }  
                q.push(nxt[u][i]);  
            }  
        }  
    }  
}
```

### 2.2.3 拓扑排序优化

#### 劣势分析

上述代码有两处劣势：

在构建 fail 指针的部分，对于 BFS 内部的 while 代码，如果要处理类似于 aaaaaaaa 的字符串，这个字符串在 trie 下是非常深的，当处理 fail 结点时，aaaaaaaa 的 fail 指针指向 aaaaaaa，然后指向 aaaaaa ……，指向 aa ，然后指向 a ，最后指向 root，fail 链很深，这个复杂度很明显会退化。

在匹配阶段，假如让模式串 b 匹配主串 aaaa……a，每走一个字符就要跳 fail 链，而 fail 链特别长，也会导致复杂度退化。

#### 优化

我们注意到 BFS 和拓扑排序实际上是非常相似的，在处理结点 $u$ 的时候，所有比 $u$ 深度小的结点都已经处理完了。

在刚刚的做法中我们对每个 `nxt[u][i]` 都要跳一遍 fail 链，那我们不妨考虑把这个路径压缩，提前存储 `fail[u]` 能最终走到哪里，这样就不需要每次都跳了。

接下来考虑 `nxt[u][i]` 不存在的情况，我们引入虚边，我们调整一下 `nxt[u][i]` 的定义，将其变成：

从结点 $u$ 出发，通过走字符为 $i$ 的边，在自动机中最终能到达的结点。

因此如果 `nxt[u][i]` 存在，那么答案就是它。
如果不存在，答案就是沿 fail 链跳完后找到的结点，这就是所谓的虚边。

那么对于一个不存在的 `nxt[u][i]` ，我们试试跳到 `fail[u]` 看看能不能走边 $i$ ，如果没有我们继续往前找。因为我们已经提前存储了 `fail[u]` ，就省去了跳 fail 链的过程，故 `nxt[u][i]` 的结果就是 $nxt[fail[u]][i]$ 。

综上，我们可以这样优化：

```cpp
void findFail() {  
    queue<int> q;  
    for (int i = 0 ; i < 62 ; i++) {  
        if (nxt[0][i]) {  
            fail[nxt[0][i]] = 0;  
            q.push(nxt[0][i]);  
        }  
    }  
    while (!q.empty()) {  
        int u = q.front();  
        q.pop();  
        for (int i = 0 ; i < 62 ; i++) {  
            if (nxt[u][i]) {  
                fail[nxt[u][i]] = nxt[fail[u]][i];  
                q.push(nxt[u][i]);  
            }  
            else {  
                nxt[u][i] = nxt[fail[u]][i];  
            }  
        }  
    }  
}
```

## 3. 匹配

我们通过优化，使得匹配变得很简单。

我们让主串逐字符在 trie 上跑，沿着 trie 的 fail 链向上爬，每经过一个结点 tmp 代表到达了一个字符串，如果当前是某个模式串的结尾，就累加进答案。

因为可能会出现重复计数的情况，因此我们要边跑边打标记去重。

```cpp
int match(string s) {  
    int u = 0,ans = 0;  
    for (char c : s) {  
        int v = get_id(c);  
        u = nxt[u][v];  
        int tmp = u;  
        while (tmp && !vis[tmp]) {  
            ans += cnt[tmp];  
            vis[tmp] = true;  
            tmp = fail[tmp];  
        }  
    }  
    return ans;  
}
```

# 4. 题目

[[P3808 AC 自动机（简单版）]] 模板
