---
tags:
  - 算法
  - 数据结构
  - 字符串
  - trie
aliases:
  - 字典树
  - 前缀树
---
# 1. 概念

字典树 / 前缀树 / Trie 是一棵长得像字典的树，树上每一条边代表一个字符，通过使用 Trie，我们能将[[字符串|字符串]] 以 [[树|树]] 的形式进行存储。
从根节点出发，到树上任意一个其他的节点，两点间的路径代表一个字符串，例如：

```cpp
		1
	  b/ \a
	  2   3 
	c/ \e  \d 
	4   5   6
```
在这棵字典树上，一条路径 1-2-5 对应字符串 be。
不难发现，有些字符串会共用一条子路径，例如 bc 和 be，而它们的共用子路径就对应着这两个字符串的公共前缀 “b”。

通过字典树，我们能够很方便地对字符串的前缀进行维护和查询，额外地，我们还可以维护所有字符串中，某个前缀出现的次数。

# 2. 实现
我们的目标是将字符串连成一棵树，并且使得具有公共前缀的字符串在同一棵子树上。
我们在接下来的分析中顺便解决维护前缀出现次数的功能。

定义：
$nxt[u][v]$ ：在结点 $u$ 上，下一个字符是 $v$ 所在的结点。
$cnt[x]$ 以字符 $x$ 结尾的单词个数。

为了能够存储字符，我们要将每一个字符映射到一个固定的整数范围内

## 2.1 存储 
对于结点 $u$ ，如果其下一个字符 $v$ 存在对应的编号，就让当前的字符挪到 $v$ 上进行下一步操作。
如果不存在对应的编号，就创建一个编号，然后将字符挪到 $v$ 上。
最后 $cnt[u]$ 的数量+1。
我们对每一个结点都进行编号，用 $idx$ 来表示每个结点的编号。

实现如下：
```cpp
void insert(string s) {
	int u = 0; 
	for (char c : s) { 
		int v = get_id(c); 
		if (!nxt[u][v]) nxt[u][v] = ++idx; 
		u = nxt[u][v]; 
		cnt[u]++; 
	} 
}
```

## 2.2 查询 

对于一个单词，我们要查询其前缀在所有字符串中出现的次数。

我们不断向下找直到目标前缀的最后一个字符，如果不存在编号则数量为 0，否则输出 cnt[x] 即可（假设 x 是前缀的最后一个字符）。

```cpp
int query(string s) { 
	int u = 0; 
	for (char c : s) { 
		int v = get_id(c); 
		if (!nxt[u][v]) return 0; 
		u = nxt[u][v]; 
	}
	return cnt[u]; 
}
```

## 2.3 模板

我们用一个 struct 来维护 Trie，引入一个 clear 函数来进行初始化。

```cpp
struct Trie {
    int nxt[N][62];
    int cnt[N];
    int idx;

    void clear() {
        for (int i = 0; i <= idx; i++) {
            for (int j = 0; j < 62; j++) nxt[i][j] = 0;
            cnt[i] = 0;
        }
        idx = 0;
    }

    void insert(string s) {
        int u = 0;
        for (char c : s) {
            int v = get_id(c);
            if (!nxt[u][v]) nxt[u][v] = ++idx;
            u = nxt[u][v];
            cnt[u]++;
        }
    }

    int query(string s) {
        int u = 0;
        for (char c : s) {
            int v = get_id(c);
            if (!nxt[u][v]) return 0;
            u = nxt[u][v];
        }
        return cnt[u];
    }
} t;
```


# P8306 【模板】字典树 / Trie

[题目链接：](https://www.luogu.com.cn/problem/P8306)

思路见这一章的 2.1 和 2.2 部分，字典树的板子见 2.3。

```cpp
#include<bits/stdc++.h>
using namespace std;

const int N = 3000005;

int get_id(char c) {
    if (c >= 'A' && c <= 'Z') return c - 'A';
    if (c >= 'a' && c <= 'z') return c - 'a' + 26;
    return c - '0' + 52;
}

struct Trie {
    int nxt[N][62];
    int cnt[N];
    int idx;

    void clear() {
        for (int i = 0; i <= idx; i++) {
            for (int j = 0; j < 62; j++) nxt[i][j] = 0;
            cnt[i] = 0;
        }
        idx = 0;
    }

    void insert(string s) {
        int u = 0;
        for (char c : s) {
            int v = get_id(c);
            if (!nxt[u][v]) nxt[u][v] = ++idx;
            u = nxt[u][v];
            cnt[u]++;
        }
    }

    int query(string s) {
        int u = 0;
        for (char c : s) {
            int v = get_id(c);
            if (!nxt[u][v]) return 0;
            u = nxt[u][v];
        }
        return cnt[u];
    }
} t;

void solve() {
    int n, q;
    cin >> n >> q;
    t.clear();
    for (int i = 0; i < n; i++) {
        string s; cin >> s;
        t.insert(s);
    }
    while (q--) {
        string s; cin >> s;
        cout << t.query(s) << "\n";
    }
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(NULL);

    int T = 1;
    cin >> T;
    while (T--) solve();
    return 0;
}
```
