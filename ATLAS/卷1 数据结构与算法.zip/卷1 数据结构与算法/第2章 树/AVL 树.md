---
tags:
  - AVL树
  - 二叉搜索树
  - 树
  - 数据结构
  - 算法 
aliases:
  - 平衡树 
---
在 [[二叉搜索树]] 中提到：当输入的权值逐渐趋于有序的时候，会趋向于得到一条链，即二叉搜索树的退化。AVL树通过引入平衡因子，解决了退化问题。

# 1. 平衡因子

AVL树通过引入平衡因子来保证二叉搜索树的平衡，平衡因子的定义如下：
>[!definition] 定义
> 对于每棵树 $T$ ，其平衡因子=$h(leftT)-h(rightT)$ ，其中 $h(leftT)$ 和 $h(rightT)$ 分别是其左右子树的高度。

明显，根据定义，当平衡因子值为负数的时候说明右子树高度更高，为正数的时候说明左子树高度更高，为 $0$ 的时候说明两子树高度相同。

# 1. 定义和性质

## 1.1 AVL树的定义
通过引入平衡因子，我们能够对AVL树进行定义。
>[!definition] 定义
> 1. 空二叉树是一个AVL树。
> 2. 如果树 $T$ 是一棵AVL树，那么其左右子树也是AVL树，满足平衡因子的绝对值 $\leq 1$ 。
## 1.2 AVL树结点的定义
因为要对平衡因子进行计算，我们在定义结点的时候要引入当前节点对应子树的高度 height。

```cpp
struct AVLNode {  
    int val;  
    int height;  
    AVLNode *left;  
    AVLNode *right;  
    AVLNode(int value) : 
	    val(value), height(1), left(NULL), right(NULL) {}  
};
```

对于单个结点，我们初始化其高度为 1，即自己本身的高度。

## 1.3 AVL树的性质

>[!corollary] 性质 1
> 树 $T$ 的左右子树的高度差 $\leq 1$ 。

性质 1 根据定义得到，这是显然的。

>[!corollary] 性质 2
> $N$ 个结点的AVL树高度为 $O(\log N)$ 。
> 进一步地，当结点数为 $N$ 时，高度 $H$ 的最大值为 $\log_{\Phi}(\sqrt{ 5 }\times(N+1))-2$ 。

我们接下来证明性质 2 的前半部分，后半部分这里不证。

设 $f_{n}$ 为高度为 $n$ 的AVL树所包含的最少结点数，显然：

$$
f_n=
\begin{cases}
1&(n=1)\\
2&(n=2)\\
f_{n-1}+f_{n-2}+1& (n>2)
\end{cases}
$$

斐波那契数列的通项公式类似， $f_{n}$ 具有递推关系，我们于是可以求出 $f_{n}$ 的通项：

$$
f_n=\frac{5+2\sqrt{5}}{5}\left(\frac{1+\sqrt{5}}{2}\right)^n+\frac{5-2\sqrt{5}}{5}\left(\frac{1-\sqrt{5}}{2}\right)^n-1
$$

从而得到：

$$
n<\log_{\frac{1+\sqrt{5}}{2}} (f_n+1)<\frac{3}{2}\log_2 (f_n+1)
$$

因此可以推出AVL树的高度为 $O(\log f_{n})$ ，这里的 $f_{n}$ 指的是AVL树的结点个数 $N$。

>[!corollary] 性质 3
> 高度为 $H$ 的AVL树总结点数最多是 $2^{H+1}-1$

>[!corollary] 性质 4
>由 $N$ 个结点构造而成的AVL树的形态个数为：
>
>$$
>	\frac{1}{n+1}\binom{2n}{n}
>$$
>种，这是一个卡特兰数。
# 3. 平衡的调整

## 3.1 求平衡因子

要求平衡因子，本质上也就是求左右子树的高度之差：

```cpp
int getHeight(AVLNode *t) {  
    if (t == NULL) return 0;  
    return t->height;  
}  
  
int getBF(AVLNode *root) {  
    return getHeight(root->left) - getHeight(root->right);  
}
```

## 3.2 左旋和右旋

接下来我们对不满足平衡条件的搜索树进行调整使得其平衡。

平衡的调整操作 **左旋** 和 **右旋**，由于调整平衡后的树仍然是二叉搜索树，因此这两个操作均不会改变中序遍历序列。

这里介绍右旋，左旋可以同理反推。

对于一个结点 $A$ ，其右旋操作是：

1. 将 $A$ 的左孩子 $B$ 向右上（顺时针）旋转，代替 $A$ 作为这颗子树的根节点；
2. 将 $A$ 结点向右下（顺时针）旋转，作为 $B$ 的右子树的根；
3. $B$ 原来的右子树变为 $A$ 的左子树。

![[Assets/Pasted image 20260514191642.png]]

下面给出左右旋的代码：

```cpp
//右旋
AVLNode* rotateR(AVLNode* root) {  
    AVLNode *tmp = root->left;  
    root->left = tmp->right;  
    tmp->right = root;  
    
    //更新高度
    root->height = max(getHeight(root->left),getHeight(root->right)) + 1;  
    tmp->height = max(getHeight(tmp->left),getHeight(tmp->right)) + 1;  
    return tmp;  
}

//左旋
AVLNode* rotateL(AVLNode* root) {  
    AVLNode *tmp = root->right;  
    root->right = tmp->left;  
    tmp->left = root;  
    root = tmp;  
    
    //更新高度
    root->height = max(getHeight(root->left),getHeight(root->right)) + 1;  
    tmp->height = max(getHeight(tmp->left),getHeight(tmp->right)) + 1;  
    return tmp;  
}
```

# 4. 平衡性的破坏

分为四种破坏类型：LL，RR，LR，RL。

## 4.1 LL型

LL型指的是结点 $T$ 的左儿子的左子树过长导致平衡被破坏。
解决方案是对 $T$ 执行右旋（右单旋）。

![[Assets/Pasted image 20260514191650.png]]

## 4.2 RR型

和LL型对应，RR型指的是结点 $T$ 的右儿子的右子树过长导致平衡被破坏。
解决方案是对 $T$ 执行左旋（左单旋）。

![[Assets/Pasted image 20260514191717.png]]

## 4.3 LR型

LR型指的是结点 $T$ 的左孩子 $L$ 的右子树过长导致平衡性被破坏。
解决方案是先左旋 $L$ 变为LL型，再右旋 $T$ （左右双旋）。

![[Assets/Pasted image 20260514191725.png]]

```cpp
AVLNode* rotateLR(AVLNode* root) {  
    root->left = rotateR(root->left);  
    return rotateL(root);  
}
```

## 4.4 RL型

和LR型对应，RL型指的是结点 $T$ 的右孩子 $R$ 的左子树过长导致平衡性被破坏。
解决方案是先右旋 $R$ 变为RR型，再左旋 $T$ （右左双旋）。

![[Assets/Pasted image 20260514191706.png]]

```cpp
AVLNode* rotateRL(AVLNode* root) {  
    root->right = rotateL(root->right);  
    return rotateR(root);  
}
```

# 5. AVL树的其他操作

## 5.1 插入

插入的规则和普通二叉搜索树无异，但是插入新的结点可能会导致搜索树失衡，因此我们要在插入完成回溯的失衡判断失衡并进行对应调整。

```cpp
AVLNode* insert(AVLNode *root,int value) {  
    if (root == NULL) {  
        return new AVLNode(value);  
    }  
    if (value < root->val) root->left = insert(root->left, value);  
    else root->right = insert(root->right, value);  
    root->height = max(getHeight(root->left), getHeight(root->right)) + 1;  
    int bf = getBF(root);  
    if (bf > 1) {  
        if (value < root->left->val) return rotateL(root);  //LL
        if (value > root->left->val) return rotateLR(root);  //LR
    }  
    else if (bf < -1) {  
        if (value < root->right->val) return rotateRL(root);  //RL
        if (value > root->right->val) return rotateR(root);  //RR
    }  
    return root;  
}
```

插入操作的时间复杂度为 $O(\log N)$ 。

## 5.2 删除

和插入同理，在删除操作完成后我们判断是否失衡，如果失衡判断类型并且进行对应调整。

调整的方式有些许不同，我们要从删除的位置向上回溯，逐层检查平衡情况。
旋转类型的判断依据是该节点较高子树的方向及其孩子的平衡因子，通过判断其正负来判断旋转类型。

与插入不同，删除后可能会导致每一层都不平衡，因此可能需要旋转更多次，而插入只需执行一（LL/RR）或两次（LR/RL）。

```cpp
AVLNode* remove(AVLNode *root,int value) {  
    if (root == NULL) return root;  
    if (value < root->val) root->left = remove(root->left, value);  
    else if (value > root->val) root->right = remove(root->right, value);  
    else {  
        if (root->left == NULL) {  
            AVLNode *tmp = root->right;  
            delete root;  
            return tmp;  
        }  
        else if (root->right == NULL) {  
            AVLNode *tmp = root->left;  
            delete root;  
            return tmp;  
        }  
        else {  
            AVLNode *mnNode = findMinNode(root->right);  
            root->val = mnNode->val;  
            root->right = remove(root->right,mnNode->val);  
        }  
    }  
    root->height = max(getHeight(root->left),getHeight(root->right)) + 1;  
    int bf = getBF(root);  
    if (bf > 1) {  //L? 型
        if (getBF(root->left) >= 0) return rotateL(root);  //LL
        if (getBF(root->left) < 0) return rotateLR(root);  //LR
    }  
    else if (bf < -1) {  //R? 型
        if (getBF(root->right) <= 0) return rotateR(root);  //RR
        if (getBF(root->right) > 0) return rotateRL(root);  //RL
    }  
    return root;  
}
```

删除操作的时间复杂度为 $O(\log N)$ 。