---
tags:
  - B树
  - 树
  - 数据结构
  - 算法 
aliases:
  - 平衡树 
---
B树是 $m$阶多路平衡查找树 的典型代表，本质上是一棵 $m$ 叉树，在B树上的每个结点最多有 $m$ 棵子树，$m-1$ 个键值。

B树保证了所有的叶子结点都在同一层，使得在最坏情况下和其他情况查找路径的长度是一样的。

# 1. B树的结构
## 1.1 构成
>[!definition] 定义
>一个B树结点由 $n$ 个键值 $K_{i}$ 和 $n+1$ 个指向子树的指针 $P_{i}$ 组成，$P_{i}$  指向的子树内的所有键值的值 $K'$ 均满足 $K_{i}<K'<K_{i+1}$ 。
> ^def-5327c6

## 1.2 高度
若 $n\geq 1$ 则对任意一棵包含 $n$ 个关键字，阶数为 $m$ 的B树，其高度 $h$ 满足：

$$
\log_{m}(n+1)\leq h\leq \log_{\left\lceil  \frac{m}{2}  \right\rceil }\left(\left( \frac{n+1}{2} \right)+1\right)
$$

# 2. 性质
>[!corollary] 性质 1
>根节点若非空，则至少有两个子树，非根非叶节点的子树数量至少有 $\left\lceil  \frac{m}{2}  \right\rceil$ 棵。
> ^cor-7cf430

>[!corollary] 性质 2
>所有叶子节点都在同一层，也就是说，B树每一个结点的平衡因子均为 0 。

> [!faq] 注意
> B树中的叶子结点指的是最底端的结点所指的外部空节点，最底端的存有键值的节点为“终端节点”。

>[!corollary] 性质 3
>每个节点内的键值是有序的，可以在每个节点内实施折半查找，B树的实际实现方式与分块查找类似。

>[!corollary] 性质 4
>B树上结点的孩子个数 = 结点的关键字个数 + 1

# 3. 构造
B树的结点需要记录当前结点的键值个数，一个存储键值的数组，指向子结点的指针数组，和一个指向双亲结点的指针。

```cpp
struct BTNode{  
    int keyCnt;  
    int keys[5];  
    struct BTNode *children[6];  
    struct BTNode *parent;  
};
```

# 4. B树上的操作

## 4.1 查找操作
B树上的查找操作分为两个部分：结点间的按层跳跃和节点内的顺序或折半查找，在阶数较小的时候可以直接使用顺序查找。

假设查找数字 $x$ ，如果 $x$ 在结点的某两键值之间，那么就向下一层查找。

```cpp
struct SearchRes {  
    BTNode *node;  
    int idx;  
    bool found;  
};  
  
SearchRes BTSearch(BTNode *root,int key) {  
    BTNode *p = root, *parent = nullptr;  
    int i;  
    while (p != nullptr) {  
        for (i = 1 ; i <= p -> keyCnt && key > p->keys[i] ; i++) ;  
        if (i <= p->keyCnt && key == p->keys[i]) {  
            return SearchRes{p,i,true};  
        }  
        parent = p;  
        p = p->children[i-1];  
    }  
    return SearchRes{parent,i,false};  
}
```

## 4.2 插入操作
B树的插入操作总是发生在最底层的终端结点处。
由于B树结点的特殊性，在执行插入操作之后，还需要判断当前的树的状态是否合法。

下面设每个结点的最多关键字数为 $N=4$ 。

#### 情形一：终端结点空间足够
若终端结点的关键字数少于 $m-1$（即 `keyCnt < 4`），直接插入即可。

```cpp
void InsertNonFull(BTNode *node, int key) {
    int i = node->keyCnt;
    while (i >= 1 && key < node->keys[i]) {
        node->keys[i + 1] = node->keys[i];
        i--;
    }
    node->keys[i + 1] = key;
    node->keyCnt++;
}
```

#### 情形二：终端结点空间不足
若终端结点已满（`keyCnt == 4`），需先将要插入的键值临时并入，再以中位数 $K_{\lceil m/2 \rceil}$（即第 3 个键值）为界进行分裂：

1. 将原结点的 4 个键值与新键值合并排序，得到一个临时有序序列（共 5 个键值）
2. 第 3 个键值 $K_3$ 上升至父结点
3. $K_1, K_2$ 留在原结点（左结点），$K_4, K_5$ 移至新结点（右结点）

```cpp
BTNode *SplitChild(BTNode *node) {
    BTNode *right = new BTNode{};
    int mid = (5 + 1) / 2;            // m=5 时 mid=3

    // 右结点接收 keys[mid+1 .. 5]
    for (int i = mid + 1; i <= 5; i++) {
        right->keys[i - mid] = node->keys[i];
    }
    right->keyCnt = 5 - mid;          // 2 个键值
    node->keyCnt = mid - 1;           // 2 个键值

    return right;
}
```

由此可知，B树深度变大的方式就是根节点的分裂。

#### 插入的代码实现
```cpp
void InsertBTree(BTNode *&root, int key) {
    BTNode *p = root, *parent = nullptr;
    int i;

    // 定位到最底层终端结点
    while (p != nullptr) {
        if (p->keyCnt == 4) {               // 途经结点已满，预分裂
            BTNode *right = SplitChild(p);
            int upKey = p->keys[3];          // 中位数上升

            if (parent == nullptr) {         // 根结点分裂
                BTNode *newRoot = new BTNode{};
                newRoot->keys[1] = upKey;
                newRoot->children[0] = p;
                newRoot->children[1] = right;
                newRoot->keyCnt = 1;
                p->parent = newRoot;
                right->parent = newRoot;
                root = newRoot;
                p = (key < upKey) ? p : right;
            } else {                         // 非根结点分裂
                right->parent = parent;
                // 将 upKey 插入 parent
                for (i = parent->keyCnt; i >= 1 && upKey < parent->keys[i]; i--) {
                    parent->keys[i + 1] = parent->keys[i];
                    parent->children[i + 1] = parent->children[i];
                }
                parent->keys[i + 1] = upKey;
                parent->children[i + 1] = right;
                parent->keyCnt++;
                p = (key < upKey) ? p : right;
            }
        }
        // 继续向下
        for (i = 1; i <= p->keyCnt && key > p->keys[i]; i++);
        if (i <= p->keyCnt && key == p->keys[i]) return;  // 已存在
        parent = p;
        p = p->children[i - 1];
    }

    // 终端结点有空间，直接插入
    InsertNonFull(parent, key);
}
```

## 4.3 删除操作
对于一棵 B 树，我们要保证每个结点存的关键字数量 $\geq\left\lceil  \frac{m}{2}  \right\rceil-1$ （[[#^cor-7cf430|性质 1]] ），下文简称其为“下限”。
而对于一些不理想的情形，删除后关键字数量可能就小于这个值，因此我们需要对其进行调整。

#### 情形一：要删的元素位于终端结点
##### 元素数量足够多
如果终端结点的关键字数量严格大于下限，我们就可以正常删除而不需要进行额外调整。
##### 元素数量不够 但 兄弟结点元素数量足够多
如果该终端结点 $A$ 元素数量恰为下限，删了会导致性质被破坏，但是兄弟结点 $B$ 的元素数量足够宽裕，我们考虑向兄弟节点借位，进行如下操作：

1. 把父亲结点 $F$ 介于两个结点间的关键字取下，放在 $A$ 里。
2. 把兄弟结点 $B$ 的边界值取下，送上父亲结点 $F$ 中。

对于第二个操作，如果 $B$ 是 $A$ 的右兄弟，则取最小值，如果是左兄弟，就取最大值。
##### 元素数量不够 且 兄弟节点元素数量也不够
如果该终端结点 $A$ 元素数量恰为下限，并且兄弟结点 $B$ 的元素数量也恰为下限，我们则考虑合并这两个结点，操作如下：

1. 将结点 $A$ 和 $B$ ，以及父亲节点 $F$ 介于两个结点间的关键字合并成一个新的大结点 $C$ 。
2. 此时父亲会失去一个关键字，如果父亲的数量也小于下限，则递归处理，向上进行借位或者合并。

如果操作 2 递归到了根节点也被合并，则这棵树的深度-1 。

#### 情形二：要删的数不在终端节点
首先我们肯定不能直接对这个结点删除元素，否则会导致树的断裂，我们考虑如下操作：

1. 找到要删的关键字 $K$ ，然后找到其 **左子树里的最大值 $L$** 和 **右子树里的最小值 $R$** 。根据 [[B树#^def-5327c6|B树的定义]] ，我们能保证 $L$ 和 $R$ 一定在终端结点上。
2. 我们用 $L$ 或 $R$ 的值覆盖 $K$ ，假设这里我们用 $L$。
3. 现在这个问题等价于删除终端结点上的元素 $L$ ，就回到了 [[#情形一：要删的元素位于终端结点]] 。

B树的删除操作较为复杂，需要考虑多种情况，总的而言，可以归纳为下面的决策树：

```python
					要删除关键字 K
                          |
                     K 在内节点吗？
                     /         \
                 [否]          [是] 
                 /                 \
        用前驱/后继覆盖 K          删除后数量 >= 下限？
              |                        /       \
         转化为[是]                   [是]        [否] (违规)
                                     /            \
                                  直接删除       兄弟够借吗？
                                               /        \
                                             [是]        [否]
                                             /              \
                                         旋转借位         合并兄弟与父亲
                                                         (可能向上递归)
```
 
# 5. B树的优化
通过在B树的基础上添加索引，将终端节点串联，可以构造出更优的 [[B+树|B+树]] 。